// import logo from './logo.svg';
import './App.css';



function App() {

  function submit(a) {
    let lat = document.getElementById("lat").value
    let long = document.getElementById("long").value
    fetch(`http://api.geonames.org/timezoneJSON?lat=${lat}&lng=${long}&username=ranjith`, { method: 'GET' })
      .then(response => response.text())
      .then(result => {
        result = JSON.parse(result);
        let innerhtml = `<p>Sunrise: ${result.sunrise}</p><p>Sunset : ${result.sunset}</p>`
        document.getElementById("res").innerHTML = innerhtml
        console.log(result)
      })
      .catch(error => console.log('error', error));
  
  }

  let html =  (
    <div class="body">
      <div class="login-container">
        <h2>TIME ZONE</h2>

        <div class="form-group">
          <input type="text" placeholder="Lat" id="lat" name="lat" required />
        </div>

        <div class="form-group">
          <input type="text" placeholder="long" id="long" name="long" required />
        </div>

        <button type="submit" class="login-btn" onClick={submit}>SUBMIT</button>
       
        <div id="res"></div>

      </div>
    </div>
  );

  return html;
}

export default App;
